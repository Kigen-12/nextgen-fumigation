const menuToggle=document.querySelector(".menu-toggle"),navLinks=document.querySelector(".nav-links");
menuToggle.addEventListener("click",()=>{const open=navLinks.classList.toggle("open");menuToggle.setAttribute("aria-expanded",open);menuToggle.textContent=open?"✕":"☰"});
document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>{navLinks.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");menuToggle.textContent="☰"}));
document.getElementById("year").textContent=new Date().getFullYear();

document.getElementById("quoteForm").addEventListener("submit",function(e){
 e.preventDefault();
 const name=document.getElementById("qName").value.trim();
 const service=document.getElementById("qService").value;
 const location=document.getElementById("qLocation").value.trim();
 const message=document.getElementById("qMessage").value.trim();
 const text=`Hello NEXTGEN Fumigation & Cleaning Services,%0A%0AMy name is ${encodeURIComponent(name)}.%0AService needed: ${encodeURIComponent(service)}.%0ALocation: ${encodeURIComponent(location)}.%0AAdditional details: ${encodeURIComponent(message||"None")}.%0A%0AI would like to request a quote.`;
 window.open(`https://wa.me/254790676223?text=${text}`,"_blank");
});
